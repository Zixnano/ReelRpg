extends Node

signal state_changed(new_state: String)
signal inventory_changed
signal message(text: String)

const SAVE_PATH := "user://reel_rpg_save.json"
const ANIMALS := {
	"Otter": {"passive":"Fishing safe zone +15%", "safe":1.15},
	"Cat": {"passive":"Perfect hooks give +2 advantage", "perfect":2},
	"Fox": {"passive":"Big fish rare loot +20%", "rare":1.2},
	"Capybara": {"passive":"Tension drains 20% slower", "drain":0.8},
	"Badger": {"passive":"Upgrades cost 10% less", "discount":0.9},
	"Rabbit": {"passive":"Rhythm window +20%", "rhythm":1.2},
	"Duck": {"passive":"Ignores sailing weather", "weather":true},
	"Beaver": {"passive":"Cooking yields double rations", "cook":2}
}
const FISH := [
	{"name":"Minnow","tier":0,"weight":1,"gold":4,"power":5},
	{"name":"Bluegill","tier":0,"weight":2,"gold":7,"power":7},
	{"name":"Red Snapper","tier":1,"weight":3,"gold":15,"power":12},
	{"name":"Swordfin","tier":1,"weight":4,"gold":22,"power":16},
	{"name":"Bluefin Tuna","tier":2,"weight":5,"gold":40,"power":23},
	{"name":"Gulperjack","tier":2,"weight":6,"gold":55,"power":28},
	{"name":"Stormray","tier":3,"weight":8,"gold":95,"power":38},
	{"name":"Golden Leviathan","tier":4,"weight":12,"gold":250,"power":55}
]
var state := "title"
var partner := "Otter"
var gold := 50
var level := 1
var xp := 0
var rod_level := 1
var hull_level := 1
var engine_level := 1
var tension := 100.0
var max_tension := 100.0
var inventory := {"Bait":5,"Fillet":0,"Scrap":0,"Organ":0,"Ration":2,"Potion":2,"Pearl":0}
var pets: Array = []
var caught: Array = []
var current_fish: Dictionary = {}
var island := "Home Island"
var legendary_unlocked := false
var quest_progress := 0
var day := 1
var weapon := "Sword"
var last_message := ""

func _ready() -> void:
	randomize()
	load_game()
	if pets.is_empty():
		pets = [{"name":"Minnow","level":1,"power":5,"weapon":"Sword"}]

func set_state(value: String) -> void:
	state = value
	state_changed.emit(state)

func trait(key: String, fallback: Variant = 1.0) -> Variant:
	return ANIMALS.get(partner, ANIMALS.Otter).get(key, fallback)

func say(value: String) -> void:
	last_message = value
	message.emit(value)

func add_item(item: String, amount: int) -> void:
	inventory[item] = int(inventory.get(item, 0)) + amount
	inventory_changed.emit()

func choose_fish(big_bias: float = 0.0) -> Dictionary:
	var roll := randf()
	var max_tier := 1
	if engine_level >= 2: max_tier = 2
	if engine_level >= 3: max_tier = 3
	if legendary_unlocked and engine_level >= 4: max_tier = 4
	if roll < 0.05 + big_bias: max_tier = mini(4, max_tier + 1)
	var pool: Array = []
	for fish in FISH:
		if int(fish.tier) <= max_tier:
			pool.append(fish)
	var result: Dictionary = pool.pick_random().duplicate(true)
	current_fish = result
	return result

func catch_fish(fish: Dictionary) -> void:
	caught.append(fish)
	add_item("Fillet", maxi(1, int(fish.weight) / 2))
	add_item("Scrap", 1)
	gold += int(fish.gold) / 2
	xp += int(fish.power)
	quest_progress += 1
	if xp >= level * 25:
		xp -= level * 25
		level += 1
		max_tension += 5
		tension = max_tension
	say("Caught %s! +%d gold" % [fish.name, int(fish.gold) / 2])
	save_game()

func butcher_fish() -> void:
	if caught.is_empty():
		say("No fish to butcher yet.")
		return
	var fish: Dictionary = caught.pop_front()
	var weight := int(fish.weight)
	add_item("Fillet", weight)
	add_item("Scrap", maxi(1, weight / 2))
	add_item("Organ", 1)
	gold += int(fish.gold)
	say("Butchered %s into cuts and parts. +%d gold." % [fish.name, int(fish.gold)])
	save_game()

func cook_bait() -> void:
	if int(inventory.Fillet) < 1 or int(inventory.Scrap) < 1:
		say("You need 1 Fillet and 1 Scrap.")
		return
	add_item("Fillet", -1)
	add_item("Scrap", -1)
	add_item("Bait", 2 * int(trait("cook", 1)))
	add_item("Ration", int(trait("cook", 1)))
	say("Made bait and a hearty ration!")
	save_game()

func upgrade(kind: String) -> void:
	var cost := int((rod_level if kind == "rod" else hull_level if kind == "hull" else engine_level) * 40 * float(trait("discount", 1.0)))
	if gold < cost:
		say("Not enough gold. Need %d." % cost)
		return
	gold -= cost
	match kind:
		"rod": rod_level += 1
		"hull": hull_level += 1; max_tension += 15; tension = max_tension
		"engine": engine_level += 1
	say("%s upgraded!" % kind.capitalize())
	save_game()

func save_game() -> void:
	var data := {"partner":partner,"gold":gold,"level":level,"xp":xp,"rod_level":rod_level,
		"hull_level":hull_level,"engine_level":engine_level,"tension":tension,"max_tension":max_tension,
		"inventory":inventory,"pets":pets,"caught":caught,"island":island,"legendary_unlocked":legendary_unlocked,
		"quest_progress":quest_progress,"day":day}
	var file := FileAccess.open(SAVE_PATH, FileAccess.WRITE)
	if file:
		file.store_string(JSON.stringify(data))

func load_game() -> void:
	if not FileAccess.file_exists(SAVE_PATH): return
	var file := FileAccess.open(SAVE_PATH, FileAccess.READ)
	if not file: return
	var parsed = JSON.parse_string(file.get_as_text())
	if typeof(parsed) != TYPE_DICTIONARY: return
	for key in parsed:
		if key in ["partner","gold","level","xp","rod_level","hull_level","engine_level","tension","max_tension","inventory","pets","caught","island","legendary_unlocked","quest_progress","day"]:
			set(key, parsed[key])
