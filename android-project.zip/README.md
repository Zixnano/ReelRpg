# Reel RPG — Godot 4 project

This is a playable, touch-friendly Godot 4 starter game project with:
- 8 animal partners and passives
- Three fishing interaction styles
- Big-fish battle transitions
- Turn-based battles using line tension as HP
- Butchering, cooking, bait, upgrades, travel, quests and autosaves
- UI built from Godot Controls and flat-color shapes so art can be replaced later

Open `project.godot` in Godot 4.3+ and run the project. The included `.tscn` screen shells are provided as separate scene entry points; `Main.tscn` runs the complete UI.

## Android
The project uses touch-friendly buttons and `canvas_items` stretch. Set up an Android export preset in Godot and export an APK using your installed Android SDK/JDK. No external assets or plugins are required.

## Notes
This is a complete playable foundation rather than a content-final commercial release. The visual style is deliberately asset-ready: replace the generated UI panels and backgrounds with sprite sheets as they are created.
